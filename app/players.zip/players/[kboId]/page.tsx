'use client';

import { useEffect, useState } from 'react';

interface Player {
  name: string;
  backNumber: string;
  position: string;
  kboId: string;
}

export default function PlayerPage({ params }: { params: { id: string } }) {
  const [player, setPlayer] = useState<Player | null>(null);
  const [stats, setStats] = useState<Record<string, any> | null>(null);
  const [latestGame, setLatestGame] = useState<Record<string, any> | null>(null);

  const id = decodeURIComponent(params.id); // id는 kboId (예: '69737')

  useEffect(() => {
    fetch('/PlayerList.json')
      .then(res => res.json())
      .then((list: Player[]) => {
        const p = list.find(player => player.kboId === id); // ✅ 수정: 이름 → kboId
        if (p) {
          setPlayer(p);
          const type = p.position.includes('투수') ? 'pitcher' : 'hitter';
          const kboId = p.kboId;

          // 누적 시즌 성적 불러오기
          fetch(`/data/${type}_${kboId}.json`)
            .then(res => res.ok ? res.json() : null)
            .then(setStats);

          // 최근 1경기 기록 불러오기
          fetch(`/gameLogs/${type}_${kboId}_latest.json`)
            .then(res => res.ok ? res.json() : null)
            .then(setLatestGame)
            .catch(() => setLatestGame(null));
        }
      });
  }, [id]);

  if (!player) return <div className="p-4">선수 정보를 찾을 수 없습니다.</div>;

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-1">{player.name}</h1>
      <p className="text-sm text-gray-600 mb-4">#{player.backNumber} / {player.position}</p>

      {/* 최근 경기 */}
      {latestGame && (
        <div className="mb-6 p-4 border border-gray-200 bg-white rounded-xl shadow-sm">
          <h2 className="text-base font-semibold text-gray-800 mb-3">
            📅 최근 경기 기록 ({latestGame.date} vs {latestGame.opponent})
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm border border-gray-300">
              <thead className="bg-gray-100">
                <tr>
                  {Object.keys(latestGame)
                    .filter(k => k !== 'date' && k !== 'opponent')
                    .map(key => (
                      <th key={key} className="px-2 py-1 border text-xs text-gray-600 font-medium">
                        {key.toUpperCase()}
                      </th>
                    ))}
                </tr>
              </thead>
              <tbody>
                <tr className="bg-white">
                  {Object.entries(latestGame)
                    .filter(([k]) => k !== 'date' && k !== 'opponent')
                    .map(([k, v]) => (
                      <td key={k} className="px-2 py-1 text-center border text-sm">
                        {v ?? '-'}
                      </td>
                    ))}
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 시즌 누적 성적 */}
      {stats && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm border border-gray-300">
            <thead className="bg-gray-100">
              <tr>
                {Object.keys(stats)
                  .filter(k => !['player', 'playerId', 'year'].includes(k))
                  .map(key => (
                    <th key={key} className="px-2 py-1 border text-xs text-gray-600 font-medium">
                      {key.toUpperCase()}
                    </th>
                  ))}
              </tr>
            </thead>
            <tbody>
              <tr className="bg-white">
                {Object.entries(stats)
                  .filter(([k]) => !['player', 'playerId', 'year'].includes(k))
                  .map(([k, v]) => (
                    <td key={k} className="px-2 py-1 text-center border text-sm">
                      {v ?? '-'}
                    </td>
                  ))}
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
